﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MelonLoader;

namespace ModBase
{
    internal class ExampleModule : BaseModule
    {
        public override void OnQuickMenuInit()
        {
            MainClass.MainPage.AddButton("Button Text", "Button Tooltip", () =>
            {
                MelonLogger.Msg("Button Click!");
            });
        }
    }
}
